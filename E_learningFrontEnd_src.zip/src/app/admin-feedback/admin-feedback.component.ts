import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { LoginUserService } from '../login-user.service';

@Component({
  selector: 'app-admin-feedback',
  templateUrl: './admin-feedback.component.html',
  styleUrls: ['./admin-feedback.component.css']
})
export class AdminFeedbackComponent implements OnInit {
  feedBack:any=new Feedback();
  constructor(private loginUserService:LoginUserService) {this.fetchfeedback(); }

  ngOnInit(): void {
    
  }

  fetchfeedback(){
    this.loginUserService.getFeedback().subscribe( data =>{
      console.log(data);
      this.feedBack=data;
      console.log(this.feedBack);

  },error=> console.log(error));

  }

}
