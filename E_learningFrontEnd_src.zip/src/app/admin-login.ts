export class AdminLogin {
    sysId!: string;
    sysPassword!:string;
}
