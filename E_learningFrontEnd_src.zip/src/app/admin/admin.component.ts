import { Component, OnInit } from '@angular/core';
import { AdminLogin } from '../admin-login';
import { Router } from '@angular/router';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router:Router) { }
  admin: AdminLogin=new AdminLogin();

  ngOnInit(): void {
  }
  adminLogin(){
    if((this.admin.sysId=="7")&&(this.admin.sysPassword=="Dhaarani")){
      this.router.navigate(['/admindashboard']);
      alert("Welcome Admin!!");
    }
    else{
      alert("Bad Credentials");
    }
  }


}
