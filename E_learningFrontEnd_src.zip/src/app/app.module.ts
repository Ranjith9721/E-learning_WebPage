import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import{LoginNavbarComponent}  from './login-navbar/login-navbar.component'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import {HttpClientModule} from '@angular/common/http';
import { UserLoginComponent } from './user-login/user-login.component'
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component'
import { HomeNavbarComponent } from './home-navbar/home-navbar.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { CoursesComponent } from './courses/courses.component';
import { AboutComponent } from './about/about.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminNavbarComponent } from './admin-navbar/admin-navbar.component';
import { AdminFeedbackComponent } from './admin-feedback/admin-feedback.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';

import { MycoursesComponent } from './mycourses/mycourses.component';
import { BeginnerComponent } from './beginner/beginner.component';
import { ProComponent } from './pro/pro.component';
import { IntermediateComponent } from './intermediate/intermediate.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    UserLoginComponent,
    LoginNavbarComponent,
    HomeComponent,
    HomeNavbarComponent,
    MyProfileComponent,
    CoursesComponent,
    AboutComponent,
    FeedbackComponent,
    AdminComponent,
    AdminDashboardComponent,
    AdminNavbarComponent,
    AdminFeedbackComponent,
    AdminHomeComponent,
    MycoursesComponent,
    BeginnerComponent,
    ProComponent,
    IntermediateComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(
      [
        {path:'register-user', component: RegisterUserComponent},
        {path:'home', component: HomeComponent},
        {path:'user-login', component: UserLoginComponent},
        {path:'', component: RegisterUserComponent},
        {path:'myprofile', component:MyProfileComponent},
        {path:'courses', component:CoursesComponent},
        {path:'about',component:AboutComponent},
        {path:'feedback',component:FeedbackComponent},
        {path:'admin',component:AdminComponent},
        {path:'admindashboard',component:AdminDashboardComponent},
        {path:'adminfeedback',component:AdminFeedbackComponent},
        {path:'adminhome',component:AdminHomeComponent},
        {path:'mycourses',component:MycoursesComponent},
        {path:'beginner',component:BeginnerComponent},
        {path:'pro',component:ProComponent},
        {path:'intermediate',component:IntermediateComponent},
        
        {
          path:'home-navbar', component:HomeNavbarComponent,children:[
            {
              path:'home',component:HomeComponent
            },
            {
              path:'',component:HomeComponent
            }
          ]
        }
      ],
      
    )

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
