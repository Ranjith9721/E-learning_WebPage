import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beginner',
  templateUrl: './beginner.component.html',
  styleUrls: ['./beginner.component.css']
})
export class BeginnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
