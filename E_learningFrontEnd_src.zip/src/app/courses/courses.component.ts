import { Component, OnInit } from '@angular/core';
import { LoginUserService } from '../login-user.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  constructor(private loginUserService:LoginUserService) { }

  ngOnInit(): void {
  }
  callbeginner(){
    this.loginUserService.boolbeginner=true;
    alert("course added to your My Courses section successfully");
  }
  callintermediate(){
    this.loginUserService.boolintermediate=true;
    alert("course added to your My Courses section successfully");
  }
  callpro(){
    this.loginUserService.boolpro=true;
    alert("course added to your My Courses section successfully");
  }
}
