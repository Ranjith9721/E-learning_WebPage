export class Feedback {
    feedbackId!:BigInteger;
    name!:string;
    country!:string;
    gender!:string;
    rating!:string;

}
