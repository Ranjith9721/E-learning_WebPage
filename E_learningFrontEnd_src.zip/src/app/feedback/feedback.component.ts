import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Feedback } from '../feedback';
import { LoginUserService } from '../login-user.service';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  
  constructor(private loginUserService:LoginUserService) { }
  feed:Feedback=new Feedback();
  ngOnInit(): void {
  }
  feedback(){
    this.loginUserService.registerFeedback(this.feed).subscribe(
      data=>{console.log(data);
      alert("success")},error=>console.log(error));
    
  }

}
