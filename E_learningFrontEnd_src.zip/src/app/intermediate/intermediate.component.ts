import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intermediate',
  templateUrl: './intermediate.component.html',
  styleUrls: ['./intermediate.component.css']
})
export class IntermediateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
