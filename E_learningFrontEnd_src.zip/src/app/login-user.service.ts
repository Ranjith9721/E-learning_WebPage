import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable, observable } from 'rxjs';
import { Feedback } from './feedback';
import { User } from './user';

import { UserLogin } from './user-login';
import { UserLoginComponent } from './user-login/user-login.component';
@Injectable({
  
  providedIn: 'root'
})
export class LoginUserService {
  public userid:string="";
  boolbeginner:boolean=false;
  boolintermediate:boolean=false;
  boolpro:boolean=false;

 
  constructor(private httpClient: HttpClient) { }
  API='http://localhost:9090';
   loginUser(login: UserLogin): Observable<object> {
    console.log(login.userId);
    this.userid=login.userId;
    sessionStorage.setItem("userId",this.userid);
    console.log(sessionStorage.getItem("userId"));
    return this.httpClient.post(this.API+'/user/login',login);
  }
  
  getMyProfile(userId:String): Observable<any>{
    console.log(userId);
    return this.httpClient.get(this.API+'/myprofile'+'/'+userId);
  }
  registerFeedback(feed:Feedback): Observable<object>{
    return this.httpClient.post(this.API+'/registerFeedback',feed);
  }
  getFeedback(){
    return this.httpClient.get(this.API+'/getFeedback');
  }

  
 }


