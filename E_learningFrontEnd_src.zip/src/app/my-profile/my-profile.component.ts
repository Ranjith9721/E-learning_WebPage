import { Component, OnInit } from '@angular/core';
import { LoginUserService } from '../login-user.service';
import { User } from '../user';
import { UserLogin } from '../user-login';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  value: string="";
  myprofile:User=new User();

  constructor(private loginUserService:LoginUserService) {
    // this.myProfile();
   }
  
  ngOnInit(): void {
    this.myProfile();
  }
  myProfile(){
    this.value=this.loginUserService.userid;
    this.loginUserService.getMyProfile(this.value).subscribe( data =>{
      console.log(data);
       this.myprofile=data;
  }, error=>{ console.log(this.value);
  console.log("error occurs")});
}
}
