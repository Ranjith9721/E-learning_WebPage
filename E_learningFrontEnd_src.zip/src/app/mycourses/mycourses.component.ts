import { Component, OnInit } from '@angular/core';
import { LoginUserService } from '../login-user.service';

@Component({
  selector: 'app-mycourses',
  templateUrl: './mycourses.component.html',
  styleUrls: ['./mycourses.component.css']
})
export class MycoursesComponent implements OnInit {

  constructor(private loginUserService:LoginUserService) { }

  ngOnInit(): void {
  }
  checkbeginner(){
    if(this.loginUserService.boolbeginner)
      return true;
    else return false;
  }
  checkintermediate(){
    if(this.loginUserService.boolintermediate)
      return true;
    else return false;
  }
  checkpro(){
    if(this.loginUserService.boolpro)
      return true;
    else return false;
  }
  username(){
    // console.log(this.registerService.userDetails.name);
     return this.loginUserService.userid;
  }
}
