import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LoginUserService } from '../login-user.service';
import { UserLogin } from '../user-login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  login:UserLogin= new UserLogin();
  

  constructor(private loginUserService:LoginUserService, private router:Router) { }

  ngOnInit(): void {
  }
 
  userLogin(){
    console.log(this.login);
    this.loginUserService.loginUser(this.login).subscribe( data =>{
      alert("Login Successful");
      console.log(typeof(data));
      console.log(typeof(this.login));
      console.log(typeof(data)===typeof(this.login));
      
      this.router.navigate(["/home"]);
      },  error=>alert("Bad Credentials!!"));        
  }

  }
 

