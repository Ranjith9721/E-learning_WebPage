package com.rll.elearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RllELearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
